Discord Messenger V1.08
Copyright (C) 2024-2025 iProgramInCpp

Some useful information:

* The provided msvcrt.dll is a copy pulled from Windows 98, byte-patched to import functions
from dimeke32.dll instead of kernel32.dll.  If you don't trust it simply remove it, and it
will take msvcrt.dll from your system folder.

* DiscordMessengerNT31.exe is different from DiscordMessenger.exe only in two bytes, namely,
the subsystem version (specified as 3.10 in DiscordMessengerNT31.exe instead of 4.00).
The reason this is provided is because changing the version number to 3.10 changes all
dialogs to use a white background color, and uses bold fonts in some cases.

* When you use "make -j12 UNICODE=no DEBUG=no", the generated binary imports the long file
name versions of libcrypto-3, libssl-3, libgcc_s_dw2-1.dll, and libstdc++-6.dll.  I had to
bytepatch them to use shorter names so that people can run Discord Messenger from NT 3.1
which does not support long file names on FAT partitions.

* If the "DiscordMessenger" folder could not be created, the client will now try to save
its configuration data in a folder called "Discordm", to allow people to use DM from FAT
partitions and OSes which don't support long file names.